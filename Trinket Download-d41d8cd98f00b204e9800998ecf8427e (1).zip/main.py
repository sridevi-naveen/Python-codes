print("Welcome to Python Pizza Deliveries!")
size = input("What size pizza do you want? S, M, or L ")
add_pepperoni = input("Do you want pepperoni? Y or N ")
extra_cheese = input("Do you want extra cheese? Y or N ")

sp = 15
mp = 20
lp = 25
pp_sp = 2
pp_mlp = 3
exch = 1
bill = 0
if (size == "S" and add_pepperoni == "Y" and extra_cheese == "Y"):
  bill = sp + pp_sp + exch
  print(f"Your bill is: ${bill}")
elif (size == "S" and add_pepperoni == "Y" and extra_cheese == "N"):
  bill = sp + pp_sp
  print(f"Your bill is: ${bill}")
elif (size == "S" and add_pepperoni == "N" and extra_cheese == "Y"):
  bill = sp + exch
  print(f"Your bill is: ${bill}")
elif (size == "M" and add_pepperoni == "Y" and extra_cheese == "Y"):
  bill = mp + pp_mlp + exch
  print(f"Your bill is: ${bill}")
elif (size == "M" and add_pepperoni == "Y" and extra_cheese == "N"):
  bill = mp + pp_mlp
  print(f"Your bill is: ${bill}")
elif (size == "M" and add_pepperoni == "N" and extra_cheese == "Y"):
  bill = mp + exch
  print(f"Your bill is: ${bill}")
elif (size == "M" and add_pepperoni == "N" and extra_cheese == "N"):
  bill = mp
  print(f"Your bill is: ${bill}")
elif (size == "L" and add_pepperoni == "Y" and extra_cheese == "Y"):
  bill = lp + pp_mlp + exch
  print(f"Your bill is: ${bill}")
elif (size == "L" and add_pepperoni == "Y" and extra_cheese == "N"):
  bill = lp + pp_mlp
  print(f"Your bill is: ${bill}")
elif (size == "L" and add_pepperoni == "N" and extra_cheese == "Y"):
  bill = lp + exch
  print(f"Your bill is: ${bill}")
elif (size == "L" and add_pepperoni == "N" and extra_cheese == "N"):
  bill = lp
  print(f"Your bill is: ${bill}")
else:
  bill = sp
  print(f"Your bill is: ${bill}")