print("Welcome to the rollercoaster!")
height = int(input("What is your height in cm? "))
if(height >= 120):
  print("You can buy a ticket")
else:
  print("Sorry! Come back when you are 120 meters")