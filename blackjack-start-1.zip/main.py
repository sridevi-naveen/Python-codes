
import random
cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
wish = input("Do you want to play Blackjack? Type y or n \n")

#user and computer should each get 2 random cards.
user_cards = []
computer_cards = []
def blacjack_step1():
  if wish == "y":
    for i in range(0,2):
      n = random.choice(cards)
      user_cards.append(n)
    print (f"Your cards are: {user_cards}\n",end = '')
    
    for i in range(0,2):
      s = random.choice(cards)
      computer_cards.append(s)
    print(f"Computer cards are: {computer_cards}\n",end = '')
def sum_scores():
  sum_users_scores = 0
  sum_computer_scores = 0
  for number in user_cards:
    sum_users_scores += number
  print(f"sum of user score {sum_users_scores}")
  for number in computer_cards:
    sum_computer_scores += number
  print(f"sum of computer score {sum_computer_scores}")
  if sum_users_scores == 21:
    print("User has a blackjack. You Win!")
    return
  elif sum_computer_scores == 21:
    print("Computer has a blackjack. Computer Win!")
    return
  elif sum_users_scores >= 21:
    for i in user_cards:
      if i == 11:
        user_cards[0] = 1
        for number in user_cards:
          sum_users_scores += number
          #print(sum_users_scores)
          if sum_users_scores >= 21:
            print("You Lose")
    print("You Lose")
  else:
    second_wish = input("Do you want to choose another card? y or n \n")
    #drawing = True
    if second_wish == "y":
      for x in range(0,1):
        f = random.choice(cards)
        user_cards.append(f)
      print(user_cards)
      sum_scores()
    else:
      if sum_computer_scores < 17: 
        #while drawing == True:
        for x in range(0,2):
          n = random.choice(cards)
          computer_cards.append(n) 
        print(computer_cards)
        sum_computer_scores = 0
        for number in computer_cards:
          sum_computer_scores += number
        print(f"sum of computer score {sum_computer_scores}")
        if sum_computer_scores > 21:
          print("User Wins!")
          #drawing = False
          return
        elif(sum_users_scores > sum_computer_scores):
          print("You win!")
        elif(sum_users_scores == sum_computer_scores):
          print("Draw!")
        else:
          print("You Lose!")
        #second_round()
    #print("Computer Wins!")
#def second_round():
  

blacjack_step1()
sum_scores()
#second_round()

