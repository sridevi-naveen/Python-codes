print("Welcome to the rollercoaster!")
height = int(input("What is your height in cm? "))
if(height >= 120):
  print("You can buy a ticket.")
  age = int(input("What is your age?"))
  if(age >= 18):
    print("Pay $20")
  elif(age >= 12 and age < 18):
    print("Pay $12")
  else:
    print("You can buy a ticket." + " " +"Pay $7")
else:
  print("Sorry! Come back when you are 120 meters")
  