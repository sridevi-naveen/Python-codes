import random
# Split string method
names_string = input("Give me everybody's names, separated by a comma. \n")
names = names_string.split(", ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
x = len(names)
random_no = random.randint(0,x - 1)
print(names[random_no] + " is going to pay the bill.")