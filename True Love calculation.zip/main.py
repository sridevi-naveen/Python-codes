# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
lower_case_name1 = name1.lower()
lower_case_name2 = name2.lower()
both_name = lower_case_name1 + lower_case_name2
t_count = both_name.count("t")
r_count = both_name.count("r")
u_count = both_name.count("u")
e_count = both_name.count("e")
total_count_true = t_count + r_count + u_count + e_count
l_count = both_name.count("l")
o_count = both_name.count("o")
v_count = both_name.count("v")
ee_count = both_name.count("e")
total_count_love = l_count + o_count + v_count + ee_count
total = str(total_count_true) + str(total_count_love)
tot = int(total)
if (tot < 10 or tot > 90):
  print(f"Your score is {total}, you go together like coke and mentos.")
elif(tot >= 40 and tot <= 50):
  print(f"Your score is {total}, you are alright together.")
else:
  print(f"Your score is {total}")