from replit import clear
#HINT: You can call clear() to clear the output in the console.
import art
print(art.logo)

bids={}
more_bidders = True
def find_the_winner(bids):
  highest_bid = 0
  winner = ""
  for bidder in bids:
    bid_amount = bids[bidder]
    if bid_amount > highest_bid:
      highest_bid = bid_amount
      winner = bidder
  print(f"The winner is {winner} and bid amount is: ${highest_bid} ")    
while more_bidders == True:
  name = input("What is your name?")
  bid = int(input("What is the bid price?"))
  bids[name] = bid
  other_users = input("Are there other users who want to bid? yes or no \n")
  print(bids)
  if other_users == "yes":
    clear()
    more_bidders = True
  else:
    find_the_winner(bids)
    more_bidders = False