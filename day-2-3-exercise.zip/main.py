# 🚨 Don't change the code below 👇
age = input("What is your current age?")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
years = 90 - int(age)
months = years * 12
days = years * 365
print(f"You have {days} days, {months} months, {years} years left to enjoy in this WORLD!")







