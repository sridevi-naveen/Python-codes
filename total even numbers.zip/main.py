#Write your code below this row 👇
sum = 0
for n in range(1, 101):
  if((n % 2) == 0):
    sum += n  
print(f"The sum of even numbers is: {sum}")